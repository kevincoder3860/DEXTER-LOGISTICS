import React, { useState } from "react";
import { Truck, Bus, MapPin, Package, ShieldCheck, Clock3, Menu, X, ArrowRight, Phone, Mail, Globe2, Search, Send } from "lucide-react";

const services = [
  { icon: Bus, title: "Passenger Transport", desc: "Convenient passenger travel with route information, trip enquiries and booking support." },
  { icon: Truck, title: "Goods & Cargo Haulage", desc: "Reliable movement of commercial goods, consignments and general cargo." },
  { icon: Globe2, title: "Cross-Border Logistics", desc: "Transport coordination for journeys between Kenya and neighbouring East African countries." },
  { icon: Package, title: "Parcel & Delivery", desc: "Collection and delivery coordination for parcels and business consignments." }
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [bookingType, setBookingType] = useState("Goods / Cargo");
  const [tracking, setTracking] = useState("");
  const [trackMessage, setTrackMessage] = useState("");
  const [sent, setSent] = useState(false);

  const closeMenu = () => setMenuOpen(false);
  const handleTrack = (e) => {
    e.preventDefault();
    setTrackMessage(tracking.trim() ? "Tracking lookup will be connected when the shipment-management backend is configured. Please contact our team with your reference number for an update." : "Please enter your tracking reference.");
  };
  const handleBooking = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return <div>
    <header className="header">
      <a className="brand" href="#home" onClick={closeMenu}><img src="/dextere-logo.jpg" alt="Dextere Haulers Limited logo" /><span><b>DEXTERE HAULERS</b><small>LIMITED · TRANSPORT & LOGISTICS</small></span></a>
      <button className="menuBtn" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X/> : <Menu/>}</button>
      <nav className={menuOpen ? "nav open" : "nav"}>
        <a href="#home" onClick={closeMenu}>Home</a><a href="#services" onClick={closeMenu}>Services</a><a href="#coverage" onClick={closeMenu}>Coverage</a><a href="#tracking" onClick={closeMenu}>Track Shipment</a><a href="#booking" className="navCta" onClick={closeMenu}>Request a Quote</a>
      </nav>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="heroShade"></div>
        <div className="heroContent">
          <p className="eyebrow"><span></span> KENYA · EAST AFRICA · BEYOND</p>
          <h1>Moving people.<br/><em>Delivering possibilities.</em></h1>
          <p className="heroText">Dependable passenger transport and goods haulage, connecting destinations across Kenya and beyond its borders.</p>
          <div className="heroActions"><a className="btn primary" href="#booking">Book / Request a Quote <ArrowRight size={18}/></a><a className="btn outline" href="#services">Explore Services</a></div>
          <div className="heroTrust"><span><ShieldCheck/> Safety-minded service</span><span><MapPin/> Nationwide coverage</span><span><Clock3/> Reliable coordination</span></div>
        </div>
      </section>

      <section className="quickStrip">
        <div><b>47</b><span>Counties in Kenya</span></div><div><b>2</b><span>Core transport services</span></div><div><b>EA</b><span>Regional connections</span></div><div><b>24/7</b><span>Enquiry access online</span></div>
      </section>

      <section className="section" id="services">
        <div className="sectionHead"><p className="eyebrow green">WHAT WE DO</p><h2>Transport solutions built around your journey.</h2><p>From passenger movement to commercial cargo, Dextere Haulers Limited helps connect people, businesses and destinations.</p></div>
        <div className="serviceGrid">{services.map(({icon:Icon,title,desc}) => <article className="serviceCard" key={title}><div className="serviceIcon"><Icon/></div><h3>{title}</h3><p>{desc}</p><a href="#booking">Make an enquiry <ArrowRight size={16}/></a></article>)}</div>
      </section>

      <section className="coverage" id="coverage"><div className="coverageText"><p className="eyebrow">OUR NETWORK</p><h2>From local routes to cross-border journeys.</h2><p>Plan transport within Kenya's 47 counties and enquire about regional routes connecting Kenya with neighbouring countries, subject to route availability, permits and operational arrangements.</p><div className="countryTags"><span>Kenya</span><span>Uganda</span><span>Tanzania</span><span>Rwanda</span><span>South Sudan</span><span>Ethiopia</span></div><a className="btn light" href="#booking">Ask about your route <ArrowRight size={18}/></a></div><div className="coverageVisual"><div className="routeCircle"><Globe2 size={76}/><b>KENYA</b><small>Connecting East Africa</small></div><div className="routeLine line1"></div><div className="routeLine line2"></div><div className="routeLine line3"></div><span className="pin pin1">Nairobi</span><span className="pin pin2">Mombasa</span><span className="pin pin3">Border routes</span></div></section>

      <section className="section splitSection" id="tracking">
        <div><p className="eyebrow green">SHIPMENT UPDATES</p><h2>Track your consignment.</h2><p>Enter the reference number provided after your booking. Online tracking will become active once the company's shipment database and status-update process are connected.</p></div>
        <form className="trackBox" onSubmit={handleTrack}><label htmlFor="tracking">Tracking reference</label><div className="trackInput"><Search/><input id="tracking" value={tracking} onChange={e=>setTracking(e.target.value)} placeholder="e.g. DHL-2026-0001"/><button aria-label="Search tracking number"><ArrowRight/></button></div>{trackMessage && <p className="formNote">{trackMessage}</p>}</form>
      </section>

      <section className="bookingSection" id="booking"><div className="bookingIntro"><p className="eyebrow">LET'S GET MOVING</p><h2>Tell us what you need to move.</h2><p>Send a booking enquiry or request a quotation. Our team can follow up to confirm availability, pricing and trip details.</p><div className="contactLine"><Phone/> <span>Phone: Add company phone number</span></div><div className="contactLine"><Mail/> <span>Email: Add company email address</span></div></div>
        <form className="bookingForm" onSubmit={handleBooking}><div className="formTitle">Transport enquiry</div><div className="typeSwitch"><button type="button" className={bookingType==="Goods / Cargo"?"selected":""} onClick={()=>setBookingType("Goods / Cargo")}>Goods / Cargo</button><button type="button" className={bookingType==="Passenger"?"selected":""} onClick={()=>setBookingType("Passenger")}>Passenger</button></div>
          <div className="formGrid"><label>Full name<input required placeholder="Your name"/></label><label>Phone number<input required type="tel" placeholder="+254..."/></label><label>Pickup location<input required placeholder="Town / County"/></label><label>Destination<input required placeholder="Town / Country"/></label>{bookingType==="Goods / Cargo"?<><label>Type of goods<input placeholder="Describe the cargo"/></label><label>Estimated weight<input placeholder="e.g. 2 tonnes"/></label></>:<><label>Travel date<input type="date"/></label><label>Number of passengers<input type="number" min="1" placeholder="e.g. 2"/></label></>}</div>
          <label>Additional details<textarea rows="3" placeholder="Preferred date, cargo details, route or other requirements"/></label><button className="btn primary submitBtn" type="submit">Send enquiry <Send size={17}/></button>{sent && <p className="successNote">Your enquiry form is ready. Connect the backend or company email to receive submissions before publishing this website.</p>}
        </form>
      </section>
    </main>

    <footer><div className="footerBrand"><img src="/dextere-logo.jpg" alt="Dextere Haulers Limited"/><div><b>DEXTERE HAULERS LIMITED</b><small>Connecting Kenya. Delivering Beyond Borders.</small></div></div><p>Passenger transport · Goods haulage · Cross-border logistics</p><div className="footerBottom"><span>© {new Date().getFullYear()} Dextere Haulers Limited. All rights reserved.</span><span>Website preview · Contact details to be added</span></div></footer>
  </div>;
}
export default App;